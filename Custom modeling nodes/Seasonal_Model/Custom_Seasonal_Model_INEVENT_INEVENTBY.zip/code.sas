/*-------------------------------------------------------------------
 * copyright (c) 2025 by SAS Institute Inc., Cary NC
 * name    : forecasting-modeling-seasonalforecast-3.sas
 * purpose : Use a seasonal ESM, ARIMAX or UCM model to generate forecast,
 *           with optional INEVENT and INEVENTBY support.
 *-------------------------------------------------------------------
 *  List of strategy specific properties for this Sample
 *  (available as sas MACRO variable to be used in code):
 *     _arimaxInclude            - Specify whether to include ARIMAX model for diagnosis
 *     _esmInclude               - Specify whether to include ESM model for diagnosis
 *     _ucmInclude               - Specify whether to include UCM model for diagnosis
 *     _holdoutSampleSize        - Size of data to be used for holdout
 *     _holdoutSamplePercent     - Percentage of data to be used for holdout
 *     _selectionCriteria        - Model selection criteria
 *     _forecastTask             - Set the forecast task
 *     _inEventTableName         - CAS table name containing INEVENT definitions
 *     _inEventCaslib            - CASLIB containing the INEVENT table
 *     _eventByTableName         - CAS table name containing INEVENTBY mappings
 *     _eventByCaslib            - CASLIB containing the EventBy table
 *-------------------------------------------------------------------
 * Component needs to produce output datasets and promote to &vf_caslibOut as necessary.
 * Output dataset names:
 *     &vf_outFor          - Required table containing forecast results. It contains
 *                           BY variables, time ID variable, ACTUAL, PREDICT, STD, LOWER, UPPER, ERROR.
 *     &vf_outStat         - Required table containing summary statistics. It contains BY variables,
 *                           _REGION_, _SELECT_, _MODEL_, and various statistics of fit.
 *     &vf_outInformation  - Required table containing execution summary. It contains processing information of TSMODEL
 *                          such as number of groups, maximum time ID, number of variables, etc.
 *     &vf_outModelInfo    - Required table containing selected model information. It contains BY variables,
 *                          _MODEL_, _MODELTYPE_, and various flags for seasonal, trend, inputs, events, etc.
 *     &vf_outLog          - Required table containing log messages. It contains
 *                           BY variables, _ERRORNO_, _LOGLEN_, _LOG_.
 *     &vf_outSelect       - Required table containing model selection statistics. It contains BY variables,
 *                           _REGION_, _SELECT_, _MODEL_, _SELECTED_ and various statistics of fit.
 *     &vf_outEst          - Optional table containing parameter estimates. It contains _PARM_, _STDERR_,
 *                           _TVALUE_, _PVALUE_, and model information, etc.
 *     &vf_outFmsg         - Optional table containing forecast model selection graph. It contains
 *                            _SPECNAME_, _SPECLEN_, _FMSGPEC_, and _NAME_.
 *     &vf_outComp         - Optional table containing model forecast components. It contains BY variables,
 *                           time ID variable, _ACTUAL_, _PREDICT_, _COMP_, _STD_, _LOWER_, _UPPER_.
 *     &vf_outEvent        - Optional table containing event definitions. It contains the definitions for
 *                           event variables that are specified in an instance of the EVENT object.
 *     &vf_outEventdummy   - Optional table containing event dummy variables. It contains time ID variable,
 *                           _XVAR_(event name), X (values of event).
 *     &vf_outIndep        - Optional table containing independent variables. It contains BY variables, time ID variable,
 *                           _XVAR_(independent name) and X (values of independent variable).
 *-------------------------------------------------------------------*/

/*------------------------------------------------------
 * Define the diagnose part of script to run in TSMODEL
 *----------------------------------------------------*/
%macro tsmodelCodeDiagnose;

    * Initialize the number of diagnosed models before analysis;
    n1 = 0;
    n2 = 0;
    n3 = 0;
    n4 = 0;

    %if %upcase(&_esmInclude) eq TRUE or %upcase(&_ucmInclude) eq TRUE %then %do;
        rc = diagspecOthers.Open();
        %if %upcase(&_esmInclude) eq TRUE %then %do;
            * specifying the Exponential Smoothing Seasonal Model;
            rc = diagspecOthers.SetESM('method','bests');
        %end;
        %if %upcase(&_ucmInclude) eq TRUE %then %do;
            * specifying the UCM Seasonal Model;
            rc = diagspecOthers.SetUCM('season',1);
        %end;
        rc = diagspecOthers.SetIDM('INTERMITTENT',1000000);
        rc = diagspecOthers.Close();

        rc = diagnoseOthers.Initialize(dataframe);
        rc = diagnoseOthers.SetSpec(diagspecOthers);
        %vf_setObjectOptions(instance=diagnoseOthers, object=diagnose)
        rc = diagnoseOthers.run();

        * getting the number of models for the diagnose object;
        n1 = diagnoseOthers.nmodels();
    %end;

    %if %upcase(&_arimaxInclude) eq TRUE %then %do;
        array limit[2]/nosymbols;
        limit[1]=1;
        limit[2]=2;
        * specifying the ARIMA Seasonal specs;
        rc = diagspecPS.Open();
        rc = diagspecPS.SetARIMAX('PS',limit);
        rc = diagspecPS.SetARIMAX('IDENTIFY','BOTH');

        * specifying the intermittency threshold;
        rc = diagspecPS.SetIDM('INTERMITTENT',1000000);
        rc = diagspecPS.Close();

        * specifying the ARIMA Seasonal specs;
        rc = diagspecQS.Open();
        rc = diagspecQS.SetARIMAX('QS',limit);
        rc = diagspecQS.SetARIMAX('IDENTIFY','BOTH');

        * specifying the intermittency threshold;
        rc = diagspecQS.SetIDM('INTERMITTENT',1000000);
        rc = diagspecQS.Close();

        * specifying the ARIMA Seasonal specs;
        rc = diagspecDS.Open();
        rc = diagspecDS.SetARIMAX();
        rc = diagspecDS.SetTrend('SDIFFN', 1);
        rc = diagspecDS.SetARIMAX('IDENTIFY','BOTH');

        * specifying the intermittency threshold;
        rc = diagspecDS.SetIDM('INTERMITTENT',1000000);
        rc = diagspecDS.Close();

        rc = diagnosePS.Initialize(dataframe);
        rc = diagnosePS.SetSpec(diagspecPS);
        %vf_setObjectOptions(instance=diagnosePS, object=diagnose)
        rc = diagnosePS.run();

        rc = diagnoseQS.Initialize(dataframe);
        rc = diagnoseQS.SetSpec(diagspecQS);
        %vf_setObjectOptions(instance=diagnoseQS, object=diagnose)
        rc = diagnoseQS.run();

        rc = diagnoseDS.Initialize(dataframe);
        rc = diagnoseDS.SetSpec(diagspecDS);
        %vf_setObjectOptions(instance=diagnoseDS, object=diagnose)
        rc = diagnoseDS.run();

        * getting the number of models for each diagnose object;
        n2 = diagnosePS.nmodels();
        n3 = diagnoseQS.nmodels();
        n4 = diagnoseDS.nmodels();
    %end;


    * adding the diagnosed models into selspec object;
    rc = inselect.Open(n1+n2+n3+n4);
    %if %upcase(&_esmInclude) eq TRUE or %upcase(&_ucmInclude) eq TRUE %then %do;
        rc = inselect.AddFrom(diagnoseOthers);
    %end;
    %if %upcase(&_arimaxInclude) eq TRUE %then %do;
        rc = inselect.AddFrom(diagnosePS);
        rc = inselect.AddFrom(diagnoseQS);
        rc = inselect.AddFrom(diagnoseDS);
    %end;
    rc = inselect.Close();

%mend;

/*----------------------------------------------------------------------
 * Define the holdout selection option part of script to run in TSMODEL
 *--------------------------------------------------------------------*/
%macro tsmodelCodeSelectOption;

    %if "&_holdoutSampleSize" ne "" %then %do;
        rc = forecast.setOption('HOLDOUT', &_holdoutSampleSize);
    %end;
    %if "&_holdoutSamplePercent" ne "" %then %do;
        rc = forecast.setOption('HOLDOUTPCT', &_holdoutSamplePercent);
    %end;
    rc = forecast.setOption('CRITERION', "&_selectionCriteria");

%mend;

/*----------------------------------------------------------------------
 * Define the macro to initialize the inEvent caslib and table name
 * Backward compatibility: when node INEVENT props are blank, legacy
 * project-level event behavior is preserved.
 *--------------------------------------------------------------------*/
%macro customInEventDefaults;
    %global _inEventTableName _inEventCaslib
            _inEventLibref _inEventTableLiteral _hasUserInEvent;
    %local _prevInEventData;

    %if not %symexist(_inEventTableName) %then %let _inEventTableName=;
    %if not %symexist(_inEventCaslib) %then %let _inEventCaslib=;

    %if not %symexist(vf_inEventData) %then %do;
        %global vf_inEventData;
        %let vf_inEventData=;
    %end;

    %let _inEventLibref=_evin;
    %let _inEventTableLiteral=;
    %let _hasUserInEvent=FALSE;
    %let _prevInEventData=%superq(vf_inEventData);

	/* INEVENT not configured */
	%if %length(%superq(_inEventTableName)) = 0 and
		%length(%superq(_inEventCaslib)) = 0 %then %do;
		%return;
	%end;

	/* Partial configuration is invalid */
	%if %length(%superq(_inEventTableName)) = 0 or
		%length(%superq(_inEventCaslib)) = 0 %then %do;
		%put ERROR: Both _inEventTableName and _inEventCaslib must be specified when using INEVENT.;
        %let SYSCC=8;
        %return;
	%end;

    libname &_inEventLibref sasioca sessref=&vf_session caslib="%superq(_inEventCaslib)";

    %let _inEventTableLiteral=%sysfunc(nliteral(%superq(_inEventTableName)));

    %if not %sysfunc(exist(&_inEventLibref..&_inEventTableLiteral)) %then %do;
        %put ERROR: INEVENT table &_inEventTableLiteral does not exist in caslib %superq(_inEventCaslib).;
        libname &_inEventLibref clear;
        %let SYSCC=8;
        %return;
    %end;

    %let _hasUserInEvent=TRUE;

    /*
     * Node-level INEVENT overrides project-level INEVENT for this node run.
     * Keep only the user table in replay/version-detection scope.
        * Backward compatibility: this branch executes only when node INEVENT
        * props are explicitly provided.
     */
    %if %length(%superq(_prevInEventData)) > 0
        and %upcase(%superq(_prevInEventData)) ne %upcase(%superq(_inEventTableName)) %then %do;
        %put WARNING: Node INEVENT %superq(_inEventTableName) overrides project INEVENT sources %superq(_prevInEventData) for this seasonal node run.;
    %end;

    %let vf_inEventData=%superq(_inEventTableName);

%mend customInEventDefaults;

/*----------------------------------------------------------------------
 * Define the macro to initialize the eventBy caslib and table name
 * Backward compatibility: EventBy remains optional and node-scoped.
 * If node EventBy props are blank, no EventBy mapping is applied.
 *--------------------------------------------------------------------*/
%macro customEventByDefaults;
    %global _eventByTableName _eventByCaslib
            _eventByLibref _eventByTableLiteral _hasUserEventBy;

    %if not %symexist(_eventByTableName) %then %let _eventByTableName=;
    %if not %symexist(_eventByCaslib) %then %let _eventByCaslib=;

    %if not %symexist(vf_inEventObj) %then %do;
        %global vf_inEventObj;
        %let vf_inEventObj=;
    %end;

    %if not %symexist(vf_events) %then %do;
        %global vf_events;
        %let vf_events=;
    %end;

    %if not %symexist(vf_inEventData) %then %do;
        %global vf_inEventData;
        %let vf_inEventData=;
    %end;

    %let _eventByLibref=_evby;
    %let _eventByTableLiteral=;
    %let _hasUserEventBy=FALSE;

	/* EventBy not configured */
	%if %length(%superq(_eventByTableName)) = 0 and
		%length(%superq(_eventByCaslib)) = 0 %then %do;
		%let _hasUserEventBy=FALSE;
		%return;
	%end;

	/* Partial configuration is invalid */
	%if %length(%superq(_eventByTableName)) = 0 or
		%length(%superq(_eventByCaslib)) = 0 %then %do;
		%put ERROR: Both _eventByTableName and _eventByCaslib must be specified when using EventBy.;
        %let SYSCC=8;
        %return;
	%end;

    libname &_eventByLibref sasioca sessref=&vf_session caslib="%superq(_eventByCaslib)";

    %let _eventByTableLiteral=%sysfunc(nliteral(%superq(_eventByTableName)));

    %if not %sysfunc(exist(&_eventByLibref..&_eventByTableLiteral)) %then %do;
        %put ERROR: INEVENTBY table &_eventByTableLiteral does not exist in caslib %superq(_eventByCaslib).;
        libname &_eventByLibref clear;
        %let SYSCC=8;
        %return;
    %end;

    %let _hasUserEventBy=TRUE;

    /*
     * INEVENTBY only maps events to BY groups and series.
     * It does not define event definitions.
     */
    %if %superq(vf_inEventObj) = %str()
        and %superq(vf_events) = %str()
        and %upcase(%superq(_hasUserInEvent)) ne TRUE %then %do;

        %put ERROR: EventBy was specified, but no INEVENT or configured events are available.;
        %put ERROR: INEVENTBY maps event names to BY groups, but it does not define events.;
        libname &_eventByLibref clear;
        %let SYSCC=8;
        %return;
    %end;

%mend customEventByDefaults;

/*----------------------------------------------------------------------
 * Detect INEVENT repository format for each input event table
 *--------------------------------------------------------------------*/
%macro detectInEventRepositoryVersions;
    %local i numInEventData eventTable eventTableLiteral eventLibref obsType;

    %if not %symexist(vf_inEventData) %then %do;
        %return;
    %end;

    %let numInEventData=%sysfunc(countw(%superq(vf_inEventData), %str( )));

    %do i = 1 %to &numInEventData;
        %global _eventRepositoryVersion&i;

        %let eventTable=%scan(%superq(vf_inEventData), &i, %str( ));
        %let eventTableLiteral=%sysfunc(nliteral(%superq(eventTable)));

        /*
         * Default to HPFEVENTS because existing project-level event
         * repositories use that format.
         */
        %let _eventRepositoryVersion&i=HPFEVENTS;
        %let eventLibref=&vf_libIn;

        %if %upcase(%superq(_hasUserInEvent)) = TRUE
            and %upcase(%superq(eventTable)) = %upcase(%superq(_inEventTableName)) %then %do;
            %let eventLibref=&_inEventLibref;
        %end;

        %if %sysfunc(exist(&eventLibref..&eventTableLiteral)) %then %do;

            proc contents
                data=&eventLibref..&eventTableLiteral
                out=work._inevent_contents_&i
                noprint;
            run;

            proc sql noprint;
                select type
                    into :obsType trimmed
                from work._inevent_contents_&i
                where upcase(name) = '_OBSINTRVL_';
            quit;

            /*
             * PROC CONTENTS OUT= type:
             * 1 = numeric   => HPFEVENTS
             * 2 = character => TSMODEL
             */
            %if "&obsType" = "1" %then %do;
                %let _eventRepositoryVersion&i=HPFEVENTS;
            %end;
            %else %if "&obsType" = "2" %then %do;
                %let _eventRepositoryVersion&i=TSMODEL;
            %end;

            %put NOTE: INEVENT table &eventTableLiteral detected as &&_eventRepositoryVersion&i repository.;
        %end;
        %else %do;
            %put ERROR: INEVENT table &eventTableLiteral does not exist in caslib %superq(vf_caslibIn).;
            %let SYSCC=8;
            %return;
        %end;
    %end;
%mend detectInEventRepositoryVersions;

/*----------------------------------------------------------------------
 * Define the macro to initialize inobj to run in TSMODEL
 *--------------------------------------------------------------------*/
%macro inobjSpecify;
    %let inobj=;

    %if %upcase(%superq(_hasUserInEvent)) = TRUE %then %do;
        %let inobj=%str(&inobj inevent1 = &_inEventLibref..&_inEventTableLiteral);
    %end;

    %if %superq(vf_inEventObj) ne %str()
        and %upcase(%superq(_hasUserInEvent)) ne TRUE %then %do;
        %let inobj=%str(&inobj &vf_inEventObj);
    %end;

    %if %upcase(%superq(_hasUserEventBy)) = TRUE %then %do;
        %let inobj=%str(&inobj inEventBy = &_eventByLibref..&_eventByTableLiteral);
    %end;

    %if %superq(_forecastTask) ne DIAGNOSE %then %do;
		%let inobj=%str(inFmsg = &inDiagFmsg &inobj);

		%if %superq(_forecastTask) ne SELECT %then %do;
			%let inobj=%str(inEst = &inDiagEst &inobj);
		%end;
	%end;

    %if %superq(inobj) ne %str() %then %do;
        %let inobj=(&inobj);
    %end;
%mend inobjSpecify;

/*----------------------------------------------------------------------
 * Define macros to replay INEVENT tables and add configured events
 *--------------------------------------------------------------------*/
%macro tsmodelReplayInputEvents(eventsObj);
    %local i numInEventData repoVersion;

    %let numInEventData=%sysfunc(countw(%superq(vf_inEventData), %str( )));

    %do i = 1 %to &numInEventData;

        %if %symexist(_eventRepositoryVersion&i) %then %do;
            %let repoVersion=%upcase(%superq(_eventRepositoryVersion&i));
        %end;
        %else %do;
            %let repoVersion=HPFEVENTS;
        %end;

        %if "&repoVersion" = "TSMODEL" %then %do;
            declare object inevent&i(inevent('VERSION','TSMODEL'));
        %end;
        %else %do;
            declare object inevent&i(inevent('VERSION','HPFEVENTS'));
        %end;

        rc = &eventsObj..Replay(inevent&i);
        if rc < 0 then do;
            stop;
        end;
    %end;
%mend tsmodelReplayInputEvents;

/*----------------------------------------------------------------------
 * Define macros to add INEVENT tables and add configured events
 *--------------------------------------------------------------------*/
%macro tsmodelAddConfiguredEvents(tsdf, eventsObj);

    /*
     * Precedence contract:
     * 1) Node EventBy path (if provided)
     * 2) INEVENT-only path (node INEVENT override or project INEVENT)
     * 3) Legacy configured events path
     */

    %if %upcase(%superq(_hasUserEventBy)) = TRUE %then %do;
        /*
         * EventBy path:
         *
         * ReplayEventby adds all events associated with the current BY group
         * to the TSDF instance.
         *
         * SetEventby then restricts which events DIAGNOSE considers
         * for each BY group and Y variable based on the INEVENTBY table.
         *
        */

        rc = &tsdf..AddEvent(&eventsObj, '_all_');
        if rc < 0 then do;
            stop;
        end;

        rc = &tsdf..SetEventby(inEventBy);
        if rc < 0 then do;
            stop;
        end;

    %end;
    %else %if %superq(vf_inEventObj) ne %str()
        or %upcase(%superq(_hasUserInEvent)) = TRUE %then %do;
        /*
        * INEVENT-only path:
        *
        * INEVENT definitions have already been replayed into the EVENT object.
        * If the INEVENT table contains BY variables, Replay applies the current
        * BY group automatically.
        *
        * Add all currently available event definitions to TSDF so event dummy
        * variables are generated.
        */
        rc = &tsdf..AddEvent(&eventsObj, '_all_');
        if rc < 0 then do;
            stop;
        end;

        /*
         * Backward compatibility: when both INEVENT tables and configured/predefined
         * events (vf_events) are present, also apply %vf_addEvents so that predefined
         * ATSM calendar events (e.g. NEWYEAR, Thanksgiving) are added to the TSDF.
         * In the old codeproperty, %vf_addEvents handled both replay and predefined
         * events in a single call; preserving this ensures existing tests and projects
         * that mix inEventData tables with events entries continue to work correctly.
         */
        %if %superq(vf_events) ne %str() %then %do;
            %vf_addEvents(&tsdf, &eventsObj);
        %end;
    %end;

    %else %if %superq(vf_events) ne %str() %then %do;

        /*
        * Preserve existing standard behavior for configured/project events when no external
        * INEVENT table is supplied.
        */
        %vf_addEvents(&tsdf, &eventsObj);

    %end;

%mend tsmodelAddConfiguredEvents;

/*----------------------------------------------------------------------
 * Define the event setup part of script to run in TSMODEL
 *--------------------------------------------------------------------*/
%macro tsmodelCodeSetupEvents;

    %if %superq(vf_inEventObj) ne %str()
        or %upcase(%superq(_hasUserInEvent)) = TRUE
        or %superq(vf_events) ne %str()
        or %upcase(%superq(_hasUserEventBy)) = TRUE %then %do;

        declare object ev1(event);
        rc = ev1.Initialize();

        %if %upcase(%superq(_hasUserEventBy)) = TRUE %then %do;
            declare object inEventBy(ineventby);
        %end;

    %end;

%mend tsmodelCodeSetupEvents;

/*-------------------------------------------------------------------
declare ATSM objects
TSDF         : TSDF object groups time series variables to be used as input for the other ATSM package objects.
DIAGSPEC     : DIAGSPEC object controls specification for a time series model identification process.
DIAGNOSE     : DIAGNOSE object generates (diagnoses) time series models for a time series data.
OUTSELECT    : OUTSELECT object collects model selection statistics from a FORENG instance.
FORENG       : The FORENG object automates time series model selection and forecasting.
OUTFOR       : OUTFOR object collects forecast series from a FORENG instance.
OUTSTAT      : OUTSTAT object collects from a FORENG instance the statistics of fit for the selected model.
OUTMODELINFO : OUTMODELINFO object collects characteristics of the selected model from a FORENG instance.
OUTEST       : OUTEST object collects parameter estimates from a FORENG instance.
OUTCOMP      : OUTCOMP object collects component series from a FORENG instance.
OUTEVENT     : OUTEVENT object collects the definitions for event variables that are specified in an instance of the EVENT object.
OUTEVENTDUMMY: OUTEVENTDUMMY object collects the series for event dummy variables that are in the TSDF instance.
OUTINDEP     : OUTINDEP object collects the series for independent variables that are used in the forecast from a FORENG instance.
OUTFMSG      : OUTFMSG collector object stores the forecast model selection graph (FMSG) XML in a CAS table.
*-----------------------------------------------------------------*/
%macro tsmodelCode;
    /*declare ATSM objects;*/
    declare object dataFrame(tsdf);
    declare object inselect(selspec);
    declare object FORECAST(foreng);

    %if %upcase(&_esmInclude) eq TRUE or %upcase(&_ucmInclude) eq TRUE %then %do;
        declare object diagspecOthers(diagspec);
        declare object diagnoseOthers(diagnose);
    %end;
    %if %upcase(&_arimaxInclude) eq TRUE %then %do;
        declare object diagspecPS(diagspec);
        declare object diagspecQS(diagspec);
        declare object diagspecDS(diagspec);

        declare object diagnosePS(diagnose);
        declare object diagnoseQS(diagnose);
        declare object diagnoseDS(diagnose);
    %end;

    /*setup dependent and independent variables*/
    rc = dataFrame.initialize();
    rc = dataFrame.addY(&vf_depVar);
    %if "&vf_indepVars" ne "" %then %do;
        %vf_addXTSMODEL(dataFrame);
    %end;

    /*setup up event information*/
	%tsmodelCodeSetupEvents;

	%if %superq(vf_inEventObj) ne %str()
        or %upcase(%superq(_hasUserInEvent)) = TRUE
        or %superq(vf_events) ne %str()
        or %upcase(%superq(_hasUserEventBy)) = TRUE %then %do;

        /*
         * Backward compatibility:
         * If node INEVENT / INEVENTBY inputs are not being used,
         * preserve the legacy behavior exactly.
        */
        %if %upcase(%superq(_hasUserInEvent)) ne TRUE
            and %upcase(%superq(_hasUserEventBy)) ne TRUE %then %do;

            %vf_addEvents(dataFrame, ev1);

        %end;
        %else %do;

            /*
             * New node-level INEVENT / INEVENTBY behavior.
             */
            %if %superq(vf_inEventObj) ne %str()
                or %upcase(%superq(_hasUserInEvent)) = TRUE %then %do;
                %tsmodelReplayInputEvents(ev1);
            %end;

            %tsmodelAddConfiguredEvents(dataFrame, ev1);

        %end;

    %end;

    %if "&_forecastTask" eq "DIAGNOSE" %then %do;
        %tsmodelCodeDiagnose;
    %end;

    /*Run forecast*/
    %if "&_forecastTask" ne "DIAGNOSE" %then %do;
        %if "&_forecastTask" ne "SELECT" %then %do;
            declare object inEst(inEst);
        %end;
        declare object inFmsg(inFmsg);
    %end;

    rc = forecast.Initialize(dataFrame);

    rc = forecast.setOption('HORIZON', &vf_horizonStart);
    %if "&vf_leadExtend" eq "TRUE" %then %do;
        rc = forecast.setOption('LEAD', %eval(&vf_lead + &vf_back));
    %end;
    %else %do;
        rc = forecast.setOption('LEAD', &vf_lead);
    %end;
    rc = forecast.setOption('BACK', &vf_back);
    rc = forecast.setOption('ALPHA', &vf_alpha);

    %if "&vf_allowNegativeForecasts" eq "FALSE" %then %do;
        rc = forecast.setOption('fcst.bd.lower',0);
    %end;

    %if "&_forecastTask" eq "DIAGNOSE" or
        "&_forecastTask" eq "SELECT" %then %do;
        %tsmodelCodeSelectOption;
    %end;

    %if "&_forecastTask" eq "DIAGNOSE" %then %do;
            rc = forecast.AddFrom(inselect);
    %end;
    %if "&_forecastTask" ne "DIAGNOSE" %then %do;
        %if "&_forecastTask" eq "SELECT" %then %do;
            rc1 = forecast.replay(inFmsg);
        %end;
        %else %do;
            %if ("&_forecastTask" eq "FIT" or "&_forecastTask" eq "UPDATE") %then %do;
                rc = forecast.setOption('TASK', '&_forecastTask');
            %end;
            rc1 = forecast.replay(inFmsg, inEST);
        %end;
        %if %UPCASE("&_arimaxInclude") eq "TRUE" or %UPCASE("&_esmInclude") eq "TRUE"
            or %UPCASE("&_ucmInclude") eq "TRUE" %then %do;
            if rc1 ne 0 then do; /*replay failed: need to re-diagnose*/
                %tsmodelCodeDiagnose;
                %tsmodelCodeSelectOption;
                rc = forecast.AddFrom(inselect);
            end;
        %end;
    %end;

    rc = forecast.setOption("SEASONTEST", "AUTO");
    rc = forecast.SetOption("MINOBS.SEASON", 1);
    rc = forecast.SetOption("SEASONTEST.SIGLEVEL", 1.0);
    rc = forecast.setOption('INTERMITTENT', 1000000);
    rc = forecast.Run();

    /*collect forecast results*/
    declare object outEst(outEst);
    declare object outFor(outFor);
    declare object outFmsg(outFmsg);
    declare object outSelect(outSelect);
    declare object outModelInfo(outModelInfo);
    declare object outStat(outStat);

    rc = outEst.collect(forecast);
    rc = outFor.collect(forecast);
    rc = outFmsg.collect(forecast);
    rc = outSelect.collect(forecast);
    rc = outModelInfo.collect(forecast);
    rc = outStat.collect(forecast);

    %if %UPCASE("&_outtable_outcompInclude") eq "TRUE" %then %do;
        declare object outcomp(outcomp);
        rc = outcomp.collect(forecast);
    %end;
    %if %UPCASE("&_outtable_outeventInclude") eq "TRUE" %then %do;
        declare object outevent(outevent);
        rc = outevent.collect(ev1);
    %end;
    %if %UPCASE("&_outtable_outeventdummyInclude") eq "TRUE" %then %do;
        declare object outeventdummy(outeventdummy);
        rc = outeventdummy.collect(dataFrame);
    %end;
    %if %UPCASE("&_outtable_outindepInclude") eq "TRUE" %then %do;
        declare object outindep(outindep);
        rc = outindep.collect(forecast);
    %end;

%mend;

/*-------------------------------------------------------------------
 * main macro function call for generating forecast
 *-----------------------------------------------------------------*/
%macro seasonal_model();

    %if (not %symexist(_holdoutSampleSize)) %then %let _holdoutSampleSize = 0;
    %if (not %symexist(_holdoutSamplePercent)) %then %let _holdoutSamplePercent = .;

    %if (not %symexist(_forecastTask)) %then %let _forecastTask = DIAGNOSE;
    %let _forecastTask = %upcase(&_forecastTask);
    %customInEventDefaults;
    %if &SYSCC > 4 %then %return;
    %customEventByDefaults;
    %if &SYSCC > 4 %then %return;

    %if %upcase(%superq(_hasUserInEvent)) = TRUE
        and %upcase(%superq(_hasUserEventBy)) ne TRUE %then %do;
        %put ERROR: When you specify Event Definitions table in node properties, you must also specify a valid Event Usage table.;
        %let SYSCC=8;
        %return;
    %end;

    %detectInEventRepositoryVersions;
    %if &SYSCC > 4 %then %return;

    /*-------------------------------------------------------------------
    * %if %superq(vf_byVars) ne %str()
    * Node-level INEVENT requires node-level INEVENTBY; validation occurs above
    * before repository detection and table processing.
    *-----------------------------------------------------------------*/

    /*specify output table prefix*/
    %local outPrefix;
    %let outPrefix =;
    %if "&vf_tableOutPrefix" ne "" %then %let outPrefix =&vf_tableOutPrefix..;

    /*clean up tables from previous run*/
    proc cas;
        session &vf_session;
        table.droptable / name = "&vf_outFor" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outInformation" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outLog" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outModelInfo" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outSelect" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outEst" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outComp" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outEvent" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outEventdummy" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outIndep" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&vf_outFmsg" caslib="&vf_caslibOut", quiet=true;
    run;
    quit;

    /* checking existence of event, independent variables */
	%if "%upcase(%superq(_outtable_outeventInclude))" = "TRUE" %then %do;

		%if %superq(vf_inEventObj) = %str()
            and %upcase(%superq(_hasUserInEvent)) ne TRUE
			and %superq(vf_events) = %str()
			and %upcase(%superq(_hasUserEventBy)) ne TRUE %then %do;

			%put WARNING: Cannot create OUTEVENT table because there are no events in the project.;
			%let _outtable_outeventInclude = FALSE;
		%end;

        %if (%superq(vf_inEventObj) ne %str()
            or %upcase(%superq(_hasUserInEvent)) = TRUE)
			and %superq(vf_events) = %str()
			and %upcase(%superq(_hasUserEventBy)) ne TRUE %then %do;

			%put WARNING: OUTEVENT table can be large because it copies event definitions for all events to all BY groups.;
		%end;

	%end;

	%if "%upcase(%superq(_outtable_outeventdummyInclude))" = "TRUE" %then %do;

		%if %superq(vf_inEventObj) = %str()
            and %upcase(%superq(_hasUserInEvent)) ne TRUE
			and %superq(vf_events) = %str()
			and %upcase(%superq(_hasUserEventBy)) ne TRUE %then %do;

			%put WARNING: Cannot create OUTEVENTDUMMY table because there are no events in the project.;
			%let _outtable_outeventdummyInclude = FALSE;
		%end;

    %end;

    %if %UPCASE("&_outtable_outindepInclude") eq "TRUE" %then %do;
        %if "&vf_indepVars" eq "" %then %do;
            %put WARNING: Cannot create OUTINDEP table because there are no independent variables in the project.;
            %let _outtable_outindepInclude = FALSE;
        %end;
    %end;

    %let inDiagEst=&vf_libOut.."&outPrefix.SFDIAGNOSEOUTEST"n;
    %let inDiagFmsg=&vf_libOut.."&outPrefix.SFDIAGNOSEOUTFMSG"n;
    %let outDiagEst=&vf_libOut.."&outPrefix._SFDIAGNOSEOUTEST"n;
    %let outDiagFmsg=&vf_libOut.."&outPrefix._SFDIAGNOSEOUTFMSG"n;


    *request ODS output outInfo and name it as seasonal_outInformation;
    ods output OutInfo = seasonal_outInformation;

    *run TSMODEL to generate forecasts;

	%let inobj=%str();
	%inobjSpecify;

	proc tsmodel data = &vf_libIn.."&vf_inData"n
		logcontrol = (error = keep warning = keep)
		%if %superq(inobj) ne %str() %then %do;
			inobj = &inobj
		%end;
        outobj = (
            outFor       = &vf_libOut.."&vf_outFor"n
            outStat      = &vf_libOut.."&vf_outStat"n
            outEST       = &vf_libOut.."&outPrefix.__tmp_outEst"n
            outFmsg      = &vf_libOut.."&outPrefix.__tmp_outFmsg"n
            outSelect    = &vf_libOut.."&outPrefix._SFOUTSELECT"n
            outModelInfo = &vf_libOut.."&vf_outModelInfo"n
            %if %UPCASE("&_outtable_outcompInclude") eq "TRUE" %then outComp = &vf_libOut.."&vf_outComp"n;
            %if %UPCASE("&_outtable_outeventInclude") eq "TRUE" %then outEvent = &vf_libOut.."&vf_outEvent"n;
            %if %UPCASE("&_outtable_outeventdummyInclude") eq "TRUE" %then outEventDummy = &vf_libOut.."&vf_outEventDummy"n;
            %if %UPCASE("&_outtable_outindepInclude") eq "TRUE" %then outIndep = &vf_libOut.."&vf_outIndep"n;
        )
        outlog  = &vf_libOut.."&vf_outLog"n
        errorstop = NO
        ;

        *define time series ID variable and the time interval;
        id &vf_timeID interval = &vf_timeIDInterval
                    setmissing = &vf_setMissing trimid = LEFT nlformat = yes;

        *define time series and the corresponding accumulation methods;
        %vf_varsTSMODEL;

        *define the by variables if exist;
        %if %superq(vf_byVars) ne %str() %then %do;
			by &vf_byVars;
		%end;

        *using the ATSM (Automatic Time Series Model) package;
        require atsm;

        *starting user script;
        submit;
            %tsmodelCode;
        endsubmit;
    run;
    quit;

    *generate outinformation CAS table;
    data &vf_libOut.."&vf_outInformation"n;
        set work.seasonal_outInformation;
    run;

    data &outDiagEst / SESSREF=&vf_session;
        set &vf_libOut.."&outPrefix.__tmp_outEst"n;
    run;

    %if ("&_forecastTask" eq "DIAGNOSE") or ("&_forecastTask" eq "FORECAST") %then %do;
        data &outDiagFmsg / SESSREF=&vf_session;
            set &vf_libOut.."&outPrefix.__tmp_outFmsg"n;
        run;
    %end;
    %else %do;
		data &outDiagFmsg / SESSREF=&vf_session;
			merge &vf_libOut.."&outPrefix.__tmp_outFmsg"n &inDiagFmsg;
			%if %superq(vf_byVars) ne %str() %then %do;
				by &vf_byVars;
			%end;
		run;
    %end;

    /* promote diagnose tables (SFDIAGNOSEOUTEST,SFDIAGNOSEOUTFMSG) for incremental runs*/
    %if "&_forecastTask" ne "FORECAST" %then %do;
        %vf_promoteCASTable(localCASTable = &outPrefix._SFDIAGNOSEOUTEST,
                            globalCASTable = &outPrefix.SFDIAGNOSEOUTEST);
        %vf_promoteCASTable(localCASTable = &outPrefix._SFDIAGNOSEOUTFMSG,
                            globalCASTable = &outPrefix.SFDIAGNOSEOUTFMSG);
    %end;

    /* add _NODIAGORSELECT_ column and if &vf_dataSpecSourceChanged then retain outSelect */
    %let modoutdatelabel = Indicator of the most recent task performed. If 1, diagnose or select task has not been performed.;
    %if ("&_forecastTask" eq "DIAGNOSE") or ("&_forecastTask" eq "SELECT") %then %do;
        data &vf_libOut.."&outPrefix._SFOUTSELECT"n / SESSREF=&vf_session;
            set &vf_libOut.."&outPrefix._SFOUTSELECT"n;
            _NODIAGORSELECT_=0;
            label _NODIAGORSELECT_="&modoutdatelabel";
        run;
    %end;
    %else %do;
        /* Check if new series are added */
        proc cas;
            table.recordCount result=res status=rc /
                table={name="&outPrefix._SFOUTSELECT", caslib="&vf_caslibOut"};
            call symputx('nobs', res.recordCount[1, 'N']);
        run;
        quit;

        %if &nobs > 0 %then %do;
            /* find intersection series */
            data &vf_libOut.."&outPrefix.__intersect"n;
                merge &vf_libOut.."&outPrefix._SFOUTSELECT"n(in=a keep=&vf_byVars)
                      &vf_libOut.."&outPrefix.SFOUTSELECT"n(in=b keep=&vf_byVars);
                if a and b;
                by &vf_byVars;
            run;

            /* add flag in new series */
            data &vf_libOut.."&outPrefix.__tmpoutSelect1"n / SESSREF=&vf_session;
                set &vf_libOut.."&outPrefix._SFOUTSELECT"n;
                _NODIAGORSELECT_=0;
                label _NODIAGORSELECT_="&modoutdatelabel";
            run;

            /* update flag in old series without duplication */
            data &vf_libOut.."&outPrefix.__tmpoutselect2"n / SESSREF=&vf_session;
                merge &vf_libOut.."&outPrefix.SFOUTSELECT"n(in=a)
                      &vf_libOut.."&outPrefix.__intersect"n(in=b);
                if a and not b;
                by &vf_byVars;
                %if "&vf_dataSpecSourceChanged" eq "TRUE" %then %do;
                    _NODIAGORSELECT_=1;
                %end;
            run;

            data &vf_libOut.."&outPrefix._SFOUTSELECT"n / SESSREF=&vf_session;
                set &vf_libOut.."&outPrefix.__tmpoutselect1"n
                    &vf_libOut.."&outPrefix.__tmpoutSelect2"n;
            run;
        %end;
        %else %do;
            %if "&vf_dataSpecSourceChanged" eq "TRUE" %then %do;
                data &vf_libOut.."&outPrefix._SFOUTSELECT"n / SESSREF=&vf_session;
                    set &vf_libOut.."&outPrefix.SFOUTSELECT"n;
                    _NODIAGORSELECT_=1;
                run;
            %end;
            %else %do;
                data &vf_libOut.."&outPrefix._SFOUTSELECT"n / SESSREF=&vf_session;
                    set &vf_libOut.."&outPrefix.SFOUTSELECT"n;
                run;
            %end;
        %end;
    %end;

    proc cas;
        session &vf_session;
		table.droptable / name = "&outPrefix.__tmpoutSelect1" caslib="&vf_caslibOut", quiet=true;
		table.droptable / name = "&outPrefix.__tmpoutSelect2" caslib="&vf_caslibOut", quiet=true;
		table.droptable / name = "&outPrefix.__intersect" caslib="&vf_caslibOut", quiet=true;
    run;
    quit;

    proc cas;
        session &vf_session;
        %if %UPCASE("&_outtable_outestInclude") eq "TRUE" %then %do;
            table.copyTable /
                casout= {name= "&vf_outEst", caslib  = "&vf_caslibOut"}
                table = {name="&outPrefix.__tmp_outest",  caslib="&vf_caslibOut"};
        %end;

        %if %UPCASE("&_outtable_outfmsgInclude") eq "TRUE" %then %do;
            table.copyTable /
                casout= {name= "&vf_outFmsg", caslib  = "&vf_caslibOut"}
                table = {name="&outPrefix.__tmp_outFmsg",  caslib="&vf_caslibOut"};
        %end;

        table.copyTable /
            casout= {name= "&vf_outSelect", caslib  = "&vf_caslibOut"}
            table = {name="&outPrefix._SFOUTSELECT",  caslib="&vf_caslibOut"};

        table.droptable / name = "&outPrefix.__tmp_outest" caslib="&vf_caslibOut", quiet=true;
        table.droptable / name = "&outPrefix.__tmp_outFmsg" caslib="&vf_caslibOut", quiet=true;

    run;
    quit;

    /* keep &outPrefix.SFOUTSELECT in case &outPrefix.OUTSELECT dropped */
    %vf_promoteCASTable(localCASTable = &outPrefix._SFOUTSELECT,
                        globalCASTable = &outPrefix.SFOUTSELECT);

    proc cas;
        setsessopt / caslib = "&vf_caslibOut";
        table.droptable / name = "&outPrefix._SFOUTSELECT" caslib="&vf_caslibOut", quiet=true;
    run;
    quit;

%mend;

/*-------------------------------------------------------------------
 * Call the main macro function to generate forecast
 *-----------------------------------------------------------------*/
%seasonal_model;

/*******************************************************************************************************
Optional: promote OUTPUT Datasets.
By default following OUTPUT datasets are promoted automatically.
OUTFOR
OUTSTAT
OUTINFORMATION
OUTMODELINFO
OUTSELECT
If additional OUTPUT datasets that needs to be promoted to global scope, please use vf_promoteCASTable MACRO.
Sample code as follows:
%vf_promoteCASTable(localCASTable = localTableName, globalCASTable = globalTableName);
********************************************************************************************************/
